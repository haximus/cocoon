/*
	Copyright (c) 2004-2006, The Dojo Foundation
	All Rights Reserved.

	Licensed under the Academic Free License version 2.1 or above OR the
	modified BSD license. For more information on Dojo licensing, see:

		http://dojotoolkit.org/community/licensing.shtml
*/



({"rangeMessage":"* \u5165\u529b\u3057\u305f\u6570\u5024\u306f\u9078\u629e\u7bc4\u56f2\u5916\u3067\u3059\u3002", "invalidMessage":"* \u5165\u529b\u3057\u305f\u30c7\u30fc\u30bf\u306b\u8a72\u5f53\u3059\u308b\u3082\u306e\u304c\u3042\u308a\u307e\u305b\u3093\u3002", "missingMessage":"* \u5165\u529b\u304c\u5fc5\u9808\u3067\u3059\u3002"})