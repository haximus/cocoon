/*
	Copyright (c) 2004-2006, The Dojo Foundation
	All Rights Reserved.

	Licensed under the Academic Free License version 2.1 or above OR the
	modified BSD license. For more information on Dojo licensing, see:

		http://dojotoolkit.org/community/licensing.shtml
*/



({"months-standAlone-narrow":["1\uc6d4", "2\uc6d4", "3\uc6d4", "4\uc6d4", "5\uc6d4", "6\uc6d4", "7\uc6d4", "8\uc6d4", "9\uc6d4", "10\uc6d4", "11\uc6d4", "12\uc6d4"], "dateFormat-long":"yyyy'\ub144' M'\uc6d4' d'\uc77c'", "timeFormat-full":"a hh'\uc2dc' mm'\ubd84' ss'\ucd08' z", "eras":["\uae30\uc6d0\uc804", "\uc11c\uae30"], "timeFormat-medium":"a hh'\uc2dc' mm'\ubd84'", "dateFormat-medium":"yyyy. MM. dd", "am":"\uc624\uc804", "months-format-abbr":["1\uc6d4", "2\uc6d4", "3\uc6d4", "4\uc6d4", "5\uc6d4", "6\uc6d4", "7\uc6d4", "8\uc6d4", "9\uc6d4", "10\uc6d4", "11\uc6d4", "12\uc6d4"], "dateFormat-full":"yyyy'\ub144' M'\uc6d4' d'\uc77c' EEEE", "days-format-abbr":["\uc77c", "\uc6d4", "\ud654", "\uc218", "\ubaa9", "\uae08", "\ud1a0"], "timeFormat-long":"a hh'\uc2dc' mm'\ubd84' ss'\ucd08'", "timeFormat-short":"a hh'\uc2dc' mm'\ubd84'", "dateFormat-short":"yy. MM. dd", "pm":"\uc624\ud6c4", "months-format-wide":["1\uc6d4", "2\uc6d4", "3\uc6d4", "4\uc6d4", "5\uc6d4", "6\uc6d4", "7\uc6d4", "8\uc6d4", "9\uc6d4", "10\uc6d4", "11\uc6d4", "12\uc6d4"], "days-standAlone-narrow":["\uc77c", "\uc6d4", "\ud654", "\uc218", "\ubaa9", "\uae08", "\ud1a0"], "days-format-wide":["\uc77c\uc694\uc77c", "\uc6d4\uc694\uc77c", "\ud654\uc694\uc77c", "\uc218\uc694\uc77c", "\ubaa9\uc694\uc77c", "\uae08\uc694\uc77c", "\ud1a0\uc694\uc77c"], "field-weekday":"Day of the Week", "field-second":"Second", "field-week":"Week", "field-year":"Year", "field-minute":"Minute", "field-hour":"Hour", "field-day":"Day", "field-dayperiod":"Dayperiod", "field-month":"Month", "field-era":"Era", "field-zone":"Zone"})